# appHtmlMgr

HtmlMgr-2010.09.15-00.02.03

this repository contains the-LAST-VERSION of my HtmlMgr-app, a-java browser and wysiwyg Html editor (with minor updates to run today {2023-09-16}).

also contains the-documentation of my AAj-app written to run on HtmlMgr.

you can-download the-whole directory by downloading dirHtmlMgr.zip.

https://htmlmgr.sourceforge.net/
https://synagonism.net/dirMcs/dirCor/McsCor000002.last.html#idMcsmHmljv
